# anchor html added to headings

    <h1 id="x">abc<a class="anchor" aria-label="anchor" href="#x"/></h1>

