# build_redirect() errors if one entry is not right.

    Entry 5 in redirects must be a character vector of length 2.

