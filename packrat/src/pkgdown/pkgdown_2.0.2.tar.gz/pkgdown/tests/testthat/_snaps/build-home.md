# warns about missing images

    Code
      build_home(pkg)
    Output
      -- Building home ---------------------------------------------------------------
      Writing 'authors.html'
    Warning <rlang_warning>
      Missing images in 'README.md': 'foo.png'
      i pkgdown can only use images in 'man/figures' and 'vignettes'
    Output
      Writing '404.html'

