# warns about missing images

    Code
      build_articles(pkg)
    Output
      -- Building articles -----------------------------------------------------------
      Writing 'articles/index.html'
      Reading 'vignettes/html-vignette.Rmd'
      Writing 'articles/html-vignette.html'
    Warning <rlang_warning>
      Missing images in 'vignettes/html-vignette.Rmd': 'foo.png'
      i pkgdown can only use images in 'man/figures' and 'vignettes'

