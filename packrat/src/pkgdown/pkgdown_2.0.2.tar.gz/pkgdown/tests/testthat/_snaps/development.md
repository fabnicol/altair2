# bad mode yields good error

    Code
      check_mode("foo")
    Error <rlang_error>
      `development.mode` in `_pkgdown.yml` must be one of auto, default, release, devel, unreleased

