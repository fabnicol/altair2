# pkgdown_sitrep works

    * url in '_pkgdown.yml' not configured.

---

    * URL missing from the DESCRIPTION URL field.

---

    All good :-)

