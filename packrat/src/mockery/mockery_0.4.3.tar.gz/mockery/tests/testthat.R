library(testthat)
library(mockery)

test_check("mockery")
