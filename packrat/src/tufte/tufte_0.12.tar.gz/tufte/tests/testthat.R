library(testthat)
library(tufte)

test_check("tufte")
