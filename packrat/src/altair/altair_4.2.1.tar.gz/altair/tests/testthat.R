library(testthat)
library(altair)

test_check("altair")
