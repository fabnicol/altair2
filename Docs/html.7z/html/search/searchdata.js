var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstvwxz~",
  1: "aceilqtx",
  2: "aceflmtv",
  3: "abcdeghilmnoprstvwx~",
  4: "acdefgilmnprstv",
  5: "cvx",
  6: "be",
  7: "abcdegimnpqstv",
  8: "at",
  9: "_abdgilmnoprstvz",
  10: "dl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Définitions de type",
  6: "Énumérations",
  7: "Valeurs énumérées",
  8: "Amis",
  9: "Macros",
  10: "Pages"
};

