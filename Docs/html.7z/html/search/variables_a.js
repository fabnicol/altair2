var searchData=
[
  ['pretend',['pretend',['../class_commandline.html#a46ad0196fd8a58da9dceecc0b2d0067a',1,'Commandline::pretend()'],['../structinfo__t.html#ace62f41d04da3b35ae08765a4b0be223',1,'info_t::pretend()']]]
];
