var searchData=
[
  ['line_5fmemory_5fexception',['LINE_MEMORY_EXCEPTION',['../validator_8hpp.html#aaa499ffdded251dbf479c08bc9107521',1,'LINE_MEMORY_EXCEPTION():&#160;validator.hpp'],['../validator2_8h.html#aaa499ffdded251dbf479c08bc9107521',1,'LINE_MEMORY_EXCEPTION():&#160;validator2.h']]]
];
