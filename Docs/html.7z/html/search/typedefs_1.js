var searchData=
[
  ['vstring',['vString',['../commandline__handler_8h.html#a4dd0e07b4998ebe199d690d4eada983f',1,'vString():&#160;commandline_handler.h'],['../main_8cpp.html#a4dd0e07b4998ebe199d690d4eada983f',1,'vString():&#160;main.cpp']]]
];
