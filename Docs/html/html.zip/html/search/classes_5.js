var searchData=
[
  ['quad',['quad',['../structquad.html',1,'']]]
];
