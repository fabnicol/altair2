var searchData=
[
  ['gcc_5finline',['GCC_INLINE',['../validator_8hpp.html#a451bf468f4bb265aba601ce6e6a29969',1,'GCC_INLINE():&#160;validator.hpp'],['../validator2_8h.html#a451bf468f4bb265aba601ce6e6a29969',1,'GCC_INLINE():&#160;validator2.h']]],
  ['gcc_5funused',['GCC_UNUSED',['../validator_8hpp.html#acdb9e31626067b6b21d531acd965185f',1,'GCC_UNUSED():&#160;validator.hpp'],['../validator2_8h.html#acdb9e31626067b6b21d531acd965185f',1,'GCC_UNUSED():&#160;validator2.h']]]
];
