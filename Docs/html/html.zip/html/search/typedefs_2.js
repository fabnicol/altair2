var searchData=
[
  ['xmlchar',['xmlChar',['../validator2_8h.html#adc22d1593f2d659f7e60e0c96f9eef2b',1,'validator2.h']]],
  ['xmldocptr',['xmlDocPtr',['../validator2_8h.html#a3da10577e30ff7f9fe45ad39287131e3',1,'validator2.h']]],
  ['xmlnode',['xmlNode',['../validator2_8h.html#a9b496049f717e0def19ec2a6823033c5',1,'validator2.h']]],
  ['xmlnodeptr',['xmlNodePtr',['../validator2_8h.html#a150a25b617758d99ee2c0b41e31a2805',1,'validator2.h']]]
];
