var searchData=
[
  ['xml',['Xml',['../class_xml.html#a89c1ed39c2ba024fc98295a7d1558a2a',1,'Xml']]],
  ['xmlgetprop',['xmlGetProp',['../validator2_8h.html#a07d0aecc3d62699e160c170e089992f5',1,'validator2.h']]]
];
