var searchData=
[
  ['xml',['Xml',['../class_xml.html',1,'Xml'],['../class_xml.html#a89c1ed39c2ba024fc98295a7d1558a2a',1,'Xml::Xml()']]],
  ['xmlchar',['xmlChar',['../validator2_8h.html#adc22d1593f2d659f7e60e0c96f9eef2b',1,'validator2.h']]],
  ['xmldocptr',['xmlDocPtr',['../validator2_8h.html#a3da10577e30ff7f9fe45ad39287131e3',1,'validator2.h']]],
  ['xmlgetprop',['xmlGetProp',['../validator2_8h.html#a07d0aecc3d62699e160c170e089992f5',1,'validator2.h']]],
  ['xmlnode',['xmlNode',['../validator2_8h.html#a9b496049f717e0def19ec2a6823033c5',1,'validator2.h']]],
  ['xmlnodeptr',['xmlNodePtr',['../validator2_8h.html#a150a25b617758d99ee2c0b41e31a2805',1,'validator2.h']]]
];
