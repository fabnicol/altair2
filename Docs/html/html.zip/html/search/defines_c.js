var searchData=
[
  ['skip_5ffile',['SKIP_FILE',['../validator_8hpp.html#ab49e7f441fe09e5ef827696121663a29',1,'SKIP_FILE():&#160;validator.hpp'],['../validator2_8h.html#ab49e7f441fe09e5ef827696121663a29',1,'SKIP_FILE():&#160;validator2.h']]],
  ['strict',['STRICT',['../validator_8hpp.html#a8a7c30a576d5706b6c0821834d01cbbc',1,'validator.hpp']]]
];
