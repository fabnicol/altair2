var searchData=
[
  ['grade',['Grade',['../validator_8hpp.html#a7298899e034c29b49f749493c80a055da07bf0887bd37bd88eca435c2f2b0a829',1,'Grade():&#160;validator.hpp'],['../validator2_8h.html#a7298899e034c29b49f749493c80a055da07bf0887bd37bd88eca435c2f2b0a829',1,'Grade():&#160;validator2.h']]]
];
